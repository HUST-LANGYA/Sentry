#ifndef __TASK_POWER_READ_INA_H
#define __TASK_POWER_READ_INA_H

void task_PowerReadINA(void);
#endif //__TASK_POWER_READ_INA_H

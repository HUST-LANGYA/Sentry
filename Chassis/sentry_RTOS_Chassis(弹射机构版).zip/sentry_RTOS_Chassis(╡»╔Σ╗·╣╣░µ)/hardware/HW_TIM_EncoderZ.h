#ifndef __HW_TIM_ENCODER_Z_H
#define __HW_TIM_ENCODER_Z_H

void TIM1_Config_EncoderZ(void);
int16_t Read_Encoder_Z(void);

#endif //__HW_TIM_ENCODER_Z_H

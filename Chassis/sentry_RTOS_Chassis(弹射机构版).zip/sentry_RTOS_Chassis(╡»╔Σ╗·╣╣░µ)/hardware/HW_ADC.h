#ifndef _HW_ADC_H
#define _HW_ADC_H



#define Max_Num 2

#define ADC1_DR_Address ((u32)0x4001244C)


void ADC_Config(void);



#endif





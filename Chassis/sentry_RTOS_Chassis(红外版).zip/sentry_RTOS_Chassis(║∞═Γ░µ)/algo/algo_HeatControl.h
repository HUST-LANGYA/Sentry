#ifndef ALGO_HEAT_CONTROL_H
#define ALGO_HEAT_CONTROL_H

void HeatControl_0(void);
void HeatControl_2(void);
void HeatUpdate_0(void);
void HeatUpdate_2(void);

#endif //*ALGO_HEAT_CONTROL_H


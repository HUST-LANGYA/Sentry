#ifndef __TASK_GET_POSITION_H
#define __TASK_GET_POSITION_H


void task_getPosition(void);  //这个任务指示一个劲地区读取并融合当前位置，至于巡逻模式下地其他调控就交给底盘里的巡逻模式区处理吧

#endif  //__TASK_POSITION_H
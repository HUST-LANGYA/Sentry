#ifndef START_TASK_H
#define START_TASK_H

#include "main.h"
void start_the_very_first_task(void);

#endif

#ifndef  __TASK_UsageCPU_H
#define  __TASK_UsageCPU_H

#define MAX_strLENGTH  400//

void task_UsageCPU(void);

#endif //__TASK_UsageCPU_H


#include "main.h"
//#include "driver.h"
//#include "dshot.h"
//#include "drv_nvic.h"
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;
TIM_HandleTypeDef htim5;
extern union
{
   uint8_t sendBuffer[2*ESC_CMD_BUFFER_LEN];
   uint32_t DMA_sendBuffer[ESC_CMD_BUFFER_LEN/2];
}dshotBuffer;
extern union
{
   uint8_t sendBuffer[2*ESC_CMD_BUFFER_LEN];
   uint32_t DMA_sendBuffer[ESC_CMD_BUFFER_LEN/2];
}SK6812_Buffer;
//2021.3.25 PA1��2pwm�����
void TIM5_Config(void)
{
	htim5.Tim = TIM5;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5,ENABLE);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2,ENABLE);
	TIM_GPIO_Config(&htim5,1,GPIO_Pin_0,GPIOA);
	TIM_GPIO_Config(&htim5,2,GPIO_Pin_1,GPIOA);
	TIM_BASE_Config(&htim5,4-1,TIM_CounterMode_Up,22-1,TIM_CKD_DIV1,0);//72M
	TIM_OC_Config(&htim5,TIM_OCMode_PWM1,TIM_OutputState_Enable,TIM_OutputNState_Disable,0,TIM_OCPolarity_High,
                   TIM_OCNPolarity_High,TIM_OCIdleState_Reset,TIM_OCNIdleState_Reset);
	TIM_OC1Init(htim5.Tim,&htim5.Tim_OC);
	TIM_OC2Init(htim5.Tim,&htim5.Tim_OC);
	TIM_OC1PreloadConfig(htim5.Tim,TIM_OCPreload_Enable);
	TIM_OC2PreloadConfig(htim5.Tim,TIM_OCPreload_Enable);
	//SK6812_Buffer.DMA_sendBuffer->TIM5��DMAR
	DMA_Config(DMA2_Channel2,(uint32_t)&(TIM5->DMAR),(uint32_t)SK6812_Buffer.DMA_sendBuffer,DMA_DIR_PeripheralDST,19200,
		           DMA_PeripheralInc_Disable,DMA_MemoryInc_Enable,DMA_PeripheralDataSize_Word,DMA_PeripheralDataSize_Word,
                   DMA_Mode_Circular,DMA_Priority_Medium,DMA_M2M_Disable);
	DMA_ITConfig(DMA2_Channel2,DMA_IT_TC,ENABLE);
	NVIC_Config(DMA2_Channel2_IRQn,0,0);
	TIM_DMAConfig(TIM5,TIM_DMABase_CCR1,TIM_DMABurstLength_2Transfers); //CCR�Ĵ�������ռ�ձ�,ARR����Ƶ��
	TIM_DMACmd(TIM5,TIM_DMA_Update,ENABLE);
	DMA_Cmd(DMA2_Channel2,ENABLE);	
	TIM_ARRPreloadConfig(htim5.Tim, ENABLE);
	TIM_Cmd(htim5.Tim,ENABLE);
	TIM_CtrlPWMOutputs(htim5.Tim,ENABLE);
}


void TIM_BASE_Config(TIM_HandleTypeDef * tim,uint16_t TIM_Prescaler,uint16_t TIM_CounterMode,
	                 uint16_t TIM_Period,uint16_t TIM_ClockDivision,uint8_t TIM_RepetitionCounter)
{
	tim->Tim_Base.TIM_Prescaler = TIM_Prescaler;
	tim->Tim_Base.TIM_CounterMode = TIM_CounterMode;
	tim->Tim_Base.TIM_Period = TIM_Period;
	tim->Tim_Base.TIM_ClockDivision = TIM_ClockDivision;
	tim->Tim_Base.TIM_RepetitionCounter = TIM_RepetitionCounter;
	TIM_TimeBaseInit(tim->Tim,&tim->Tim_Base);
}

void TIM_OC_Config(TIM_HandleTypeDef * tim,uint16_t TIM_OCMode,uint16_t TIM_OutputState,
	               uint16_t TIM_OutputNState,uint16_t TIM_Pulse,uint16_t TIM_OCPolarity,
                   uint16_t TIM_OCNPolarity,uint16_t TIM_OCIdleState,uint16_t TIM_OCNIdleState)
{
	tim->Tim_OC.TIM_OCMode = TIM_OCMode;
	tim->Tim_OC.TIM_OutputState = TIM_OutputState;
	tim->Tim_OC.TIM_OutputNState = TIM_OutputNState;
	tim->Tim_OC.TIM_Pulse = TIM_Pulse;
	tim->Tim_OC.TIM_OCPolarity = TIM_OCPolarity;
	tim->Tim_OC.TIM_OCNPolarity = TIM_OCNPolarity;
	tim->Tim_OC.TIM_OCIdleState = TIM_OCIdleState;
	tim->Tim_OC.TIM_OCNIdleState = TIM_OCNIdleState;
}
//wait...
void TIM_IC_Config(TIM_HandleTypeDef * tim)
{
	
}

void TIM_GPIO_Config(TIM_HandleTypeDef * tim,int channel,
	 uint16_t GPIO_Pinx,GPIO_TypeDef *GPIOx)
{
	switch (channel)
	{
		case 1:
			  tim->TIMx_CH1.GPIO_Pin = GPIO_Pinx;
		    tim->TIMx_CH1.GPIO_Mode = GPIO_Mode_AF_PP;
		    tim->TIMx_CH1.GPIO_Speed = GPIO_Speed_50MHz;
		    GPIO_Init(GPIOx,&tim->TIMx_CH1);
			break;
		case 2:
			  tim->TIMx_CH2.GPIO_Pin = GPIO_Pinx;
		    tim->TIMx_CH2.GPIO_Mode = GPIO_Mode_AF_PP;
		    tim->TIMx_CH2.GPIO_Speed = GPIO_Speed_50MHz;
		    GPIO_Init(GPIOx,&tim->TIMx_CH2);
			break;
		case 3:
			tim->TIMx_CH3.GPIO_Pin = GPIO_Pinx;
		    tim->TIMx_CH3.GPIO_Mode = GPIO_Mode_AF_PP;
		    tim->TIMx_CH3.GPIO_Speed = GPIO_Speed_50MHz;
		    GPIO_Init(GPIOx,&tim->TIMx_CH3);
			break;
		case 4:
			tim->TIMx_CH4.GPIO_Pin = GPIO_Pinx;
		    tim->TIMx_CH4.GPIO_Mode = GPIO_Mode_AF_PP;
		    tim->TIMx_CH4.GPIO_Speed = GPIO_Speed_50MHz;
		    GPIO_Init(GPIOx,&tim->TIMx_CH4);
			break;
		default:
			break;
	}
}
void delayMs_Block(unsigned int t)
{
	int i;
	for( i=0;i<t;i++)
	{
		int a=10300;
 		while(a--);
	}
}
void delayUs_Block(unsigned int t)
{
	int i;
	for( i=0;i<t;i++)
	{
		int a=9;
		while(a--);
	}
}


void DMA_Config(DMA_Channel_TypeDef* DMAy_Channelx,uint32_t DMA_PeripheralBaseAddr,uint32_t DMA_MemoryBaseAddr,
	                uint32_t DMA_DIR,uint32_t DMA_BufferSize,uint32_t DMA_PeripheralInc,
                    uint32_t DMA_MemoryInc,uint32_t DMA_PeripheralDataSize,uint32_t DMA_MemoryDataSize,
                    uint32_t DMA_Mode,uint32_t DMA_Priority,uint32_t DMA_M2M)
{
	DMA_InitTypeDef DMA_InitStructure;
	DMA_DeInit(DMAy_Channelx);
	DMA_InitStructure.DMA_PeripheralBaseAddr = DMA_PeripheralBaseAddr;
	DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)DMA_MemoryBaseAddr;
	DMA_InitStructure.DMA_DIR = (uint32_t)DMA_DIR;	
	DMA_InitStructure.DMA_BufferSize = DMA_BufferSize;	
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize;
	DMA_InitStructure.DMA_Mode = DMA_Mode;
	DMA_InitStructure.DMA_Priority = DMA_Priority;
	DMA_InitStructure.DMA_M2M = DMA_M2M;
	DMA_Init(DMAy_Channelx, &DMA_InitStructure);

}

void NVIC_Config(uint8_t NVIC_IRQChannel,uint8_t priority,uint8_t SubPriority)
{
	NVIC_InitTypeDef nvic;
	nvic.NVIC_IRQChannel = NVIC_IRQChannel;
    nvic.NVIC_IRQChannelPreemptionPriority = priority;
    nvic.NVIC_IRQChannelSubPriority = SubPriority;
    nvic.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvic);
}



short times = 0;
extern uint8_t emd ;
void DMA2_Channel2_IRQHandler(void)
{
	if(DMA_GetFlagStatus(DMA2_FLAG_TC2)==SET)
	{	
		if(times>=20) //ÿ����20ֹͣһ��?
		{
			  times = 0;
			  //DMA_Cmd(DMA2_Channel2,DISABLE);//����ʧ����DMA
				emd = 0;//������������ʹ��		10��
		}
		times ++;
		DMA_ClearITPendingBit(DMA2_IT_TC2);
	}
}



#include "stm32f10x.h"
#include "Key_Exit.h"
//#include "led.h"
//#include "can.h"
//#include "delay.h"
#include "main.h"

void EXTI_PA8_Config(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_AFIO,ENABLE);   //开启GPIOA和AFIO时钟
	NVIC_Configuration();																										//配置嵌套向量中断控制器NVIC
	
	GPIO_InitTypeDef GPIO_InitStructure;                              //GPIO初始化
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;     //外部输入
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_8;                 //PA8
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	//开启GPIO的外部中断检测功能
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource8);        //PA8作为EXTI线
	
	EXTI_InitTypeDef EXTI_InitStructure;														//EXTI初始化
	EXTI_InitStructure.EXTI_Line=EXTI_Line8;
	EXTI_InitStructure.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger=EXTI_Trigger_Rising;
	EXTI_InitStructure.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_InitStructure);
	
}

void NVIC_Configuration(void)
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_3);     	//三位抢占优先级（preemption）,一位响应优先级（sub）
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel=EXTI9_5_IRQn;         //配置中断源，EXTI5-9线共用一个中断向量EXTI9_5_IRQn（IRQn类型） IRQ:Interrupt Quest（中断请求）
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0b0;      //最高优先级直接配置为0
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0b0;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	//NVIC_SetPriority(SysTick_IRQn, 0);                       //设置SysTick为最高抢占优先级

/*NVIC_SetPriority(SysTick_IRQn, n);
	n=0x00~0x03 设置Systick为抢占优先级0
  n=0x04~0x07 设置Systick为抢占优先级1
	n=0x08~0x0B 设置Systick为抢占优先级2
	n=0x0C~0x0F 设置Systick为抢占优先级3*/

	
}

void EXTI9_5_IRQHandler()
{
	if(EXTI_GetITStatus(EXTI_Line8)!=RESET)
	{	  
		GPIO_ResetBits(GPIOB,GPIO_Pin_0);   //点亮LED
	}
	delay_ms(10);
	GPIO_SetBits(GPIOB,GPIO_Pin_0);       //熄灭LED
	//CANSendCrash ();                      //检测到打击之后通过CAN1把打击情况发送到F105
  
	EXTI_ClearITPendingBit(EXTI_Line8);   //清除中断标志位
			
}

#ifndef __BSP_TIM2_TIMER_H
#define __BSP_TIM2_TIMER_H

//void TIM2_Config(void);
void delay_us(int32_t t);
void delay_ms(int32_t t);

void TIM2_Configuration_Timer(void);
#endif //__BSP_TIM2_TIMER_H

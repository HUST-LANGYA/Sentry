#ifndef __KEY_H
#define __KEY_H

#include "stm32f10x.h"
#define KEY_ON 0
#define KEY_OFF 1


u8 Key_Scan(GPIO_TypeDef* GPIOx,u16 GPIO_Pin);
void EXTI_PA8_Config(void);
void NVIC_Configuration(void);
void EXTI9_5_IRQHandler(void);
void Key_on_TimeDetection_ms(__IO u32 nTime);
void Key_Time_Scan_2s(GPIO_TypeDef* GPIOx,u16 GPIO_Pin,u8 a);

#endif          //__KEY_H

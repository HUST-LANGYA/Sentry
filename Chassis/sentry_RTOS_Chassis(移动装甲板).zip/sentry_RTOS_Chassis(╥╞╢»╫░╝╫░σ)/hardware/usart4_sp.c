/*****************************************************************************
* ʱ   �䣺2021��8��7��
* �ļ�����:USART4�ĳ�ʼ�����жϷ�����������λ����ͨ�Ų���
* ��   ��:Hellocoded
*****************************************************************************/

#include "main.h"

unsigned char GYRO_Buffer[GYRO_BUF_SIZE];
//Gyro_Typedef Mpu6050Receive;
uint8_t Offet_Send[OFFET_SEND_SIZE]; //���͸���λ��������
uint8_t Offet_Rece[OFFET_RECE_SIZE];
// ���շֽ�������λ��������
//uint8_t Speed_debug[2] = {0,0};
uint8_t Turn_Left_Flag = 1;
uint8_t Turn_Right_Flag = 0;
int16_t App_Speed=0;
//uint8_t Speedy[2] = {0,0};
//uint8_t Speedw[2] = {0,0};
//float Speed_Debug = 0.0f;
//float Speedy_Debug = 0.0f;
//float Speedw_Debug = 0.0f;

extern int16_t debug_SetPoint;
extern uint8_t Chassis_Debug_Mode;
extern uint8_t Last_Chassis_Debug_Mode;
extern State_t Sentry_State;
extern uint8_t R,G,B;
extern u8 DMA_end_flag;
extern uint8_t is_Under_Attack;
//extern uint8_t Led_Enable;
//extern PID_Typedef Chassis_WheelSpeed[4];
//extern ChassisSpeed_t Chassis_Speed; //�����ٶ�ֵ
void USART4_Init(void)
{
	USART_InitTypeDef usart;
	GPIO_InitTypeDef  gpio;
	NVIC_InitTypeDef  nvic;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC|RCC_APB2Periph_AFIO, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4,ENABLE);
  //RX  PC11  
	gpio.GPIO_Pin = GPIO_Pin_11;
	gpio.GPIO_Mode = GPIO_Mode_IN_FLOATING;//��������
	GPIO_Init(GPIOC,&gpio);
  //TX  PC10
	gpio.GPIO_Pin = GPIO_Pin_10;  
	gpio.GPIO_Mode = GPIO_Mode_AF_PP;
	gpio.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC	,&gpio);
  //Usart4 Init   
	USART_DeInit(UART4);
	usart.USART_BaudRate = 115200;
	usart.USART_WordLength = USART_WordLength_8b;
	usart.USART_StopBits = USART_StopBits_1;
	usart.USART_Parity = USART_Parity_No ;
	usart.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	usart.USART_HardwareFlowControl = USART_HardwareFlowControl_None;   
	USART_Init(UART4,&usart);
	//Idle Time Interrupt
	USART_ITConfig(UART4, USART_IT_IDLE, ENABLE);   
	//USART_ITConfig(UART4,USART_IT_TC,ENABLE);
	//USART_ClearFlag(UART4,USART_IT_RXNE);
	USART_Cmd(UART4,ENABLE);
	USART_DMACmd(UART4, USART_DMAReq_Tx | USART_DMAReq_Rx, ENABLE);  //�״�//�ȶ�����
	
	nvic.NVIC_IRQChannel = UART4_IRQn;
	nvic.NVIC_IRQChannelPreemptionPriority = 0;
	nvic.NVIC_IRQChannelSubPriority = 1;
	nvic.NVIC_IRQChannelCmd = ENABLE;		
	NVIC_Init(&nvic);
	 //����DMA
//	{
//		DMA_InitTypeDef  dma;
//		RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2, ENABLE);
// 		DMA_DeInit(DMA2_Channel5);
//		dma.DMA_PeripheralBaseAddr = (uint32_t)&(UART4->DR);
//		dma.DMA_MemoryBaseAddr = (uint32_t)Offet_Send;
//		dma.DMA_DIR = DMA_DIR_PeripheralDST;/*DMA_DIR_PeripheralSRC;*/
//		dma.DMA_BufferSize = OFFET_RECE_SIZE;
//		dma.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
//		dma.DMA_MemoryInc = DMA_MemoryInc_Enable;
//		dma.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
//		dma.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
//		dma.DMA_Mode = DMA_Mode_Circular; //ѭ������
//		dma.DMA_Priority = DMA_Priority_VeryHigh;
//		dma.DMA_M2M = DMA_M2M_Disable;
//		
//		nvic.NVIC_IRQChannel = DMA2_Channel5_IRQn;
//		nvic.NVIC_IRQChannelPreemptionPriority = 1;
//		nvic.NVIC_IRQChannelSubPriority = 1;
//		nvic.NVIC_IRQChannelCmd = ENABLE;
//		NVIC_Init(&nvic);
//		
//		DMA_Init(DMA2_Channel5, &dma);
//	  DMA_ITConfig(DMA2_Channel5,DMA_IT_TC,ENABLE);
//		DMA_ClearFlag(DMA2_FLAG_TC5);
//		DMA_Cmd(DMA2_Channel5, ENABLE);
//	}
	 //����DMA
	{
	  DMA_InitTypeDef  dma;
		RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2, ENABLE);
 		DMA_DeInit(DMA2_Channel3);
		dma.DMA_PeripheralBaseAddr = (uint32_t)&(UART4->DR);
		dma.DMA_MemoryBaseAddr = (uint32_t)Offet_Rece;
		dma.DMA_DIR = DMA_DIR_PeripheralSRC;
		dma.DMA_BufferSize = OFFET_RECE_SIZE;
		dma.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
		dma.DMA_MemoryInc = DMA_MemoryInc_Enable;
		dma.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
		dma.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
		dma.DMA_Mode = DMA_Mode_Circular; //ѭ������
		dma.DMA_Priority = DMA_Priority_VeryHigh;
		dma.DMA_M2M = DMA_M2M_Disable;
		
		nvic.NVIC_IRQChannel = DMA2_Channel3_IRQn;
		nvic.NVIC_IRQChannelPreemptionPriority = 1;
		nvic.NVIC_IRQChannelSubPriority = 1;
		nvic.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init(&nvic);
		
		DMA_Init(DMA2_Channel3, &dma);
		DMA_ITConfig(DMA2_Channel3,DMA_IT_TC,ENABLE);
		DMA_Cmd(DMA2_Channel3, ENABLE);  
	
	
	}
	
}


void Usart_SendByte(USART_TypeDef *pUSARTx,uint8_t ch)
{
   USART_SendData(pUSARTx,ch);
   while(USART_GetFlagStatus(pUSARTx, USART_FLAG_TXE) == RESET);
}


void Usart_SendArray( USART_TypeDef * pUSARTx, uint8_t *array, uint16_t num)
{
  uint8_t i;
	
	for(i=0; i<num; i++)
  {
	    /* ����һ���ֽ����ݵ�USART */
	    Usart_SendByte(pUSARTx,array[i]);	
  
  }
	/* �ȴ�������� */
	while(USART_GetFlagStatus(pUSARTx,USART_FLAG_TC)==RESET); //һֱ���Ͳ�����
}


int fputc(int ch, FILE *f)
{
  USART_SendData(UART4, (unsigned char) ch);// USART1 ???? USART2 ?
  while (!(UART4->SR & USART_FLAG_TXE));   // UART4
  return (ch);
}

int fgetc(FILE *f)
{
		/* �ȴ������������� */
		while (USART_GetFlagStatus(UART4, USART_FLAG_RXNE) == RESET);

		return (int)USART_ReceiveData(UART4);
}

/******************************************************
* �������ã�DMA�����ж�
*
******************************************************/


//void DMA2_Channel5_IRQHandler(void)
//{	
//	if(DMA_GetFlagStatus(DMA2_FLAG_TC5) != RESET)
//	{
//		
//		DMA_Cmd(DMA2_Channel5,DISABLE);
//		DMA_SetCurrDataCounter(DMA2_Channel5,OFFET_SEND_SIZE);
//		DMA_Cmd(DMA2_Channel5,ENABLE);
//		DMA_ClearFlag(DMA2_FLAG_TC5);
//		
//	}
//}


///******************************************************
//* ��������: DMA�����ж�
//*
//******************************************************/
//void DMA2_Channel3_IRQHandler(void)
//{
//   if(DMA_GetFlagStatus(DMA2_FLAG_TC3) == SET)
//	 {
//		  DMA_Cmd(DMA2_Channel3,DISABLE);
//		  DMA_SetCurrDataCounter(DMA2_Channel3,OFFET_SEND_SIZE);
//	    DMA_ClearFlag(DMA2_FLAG_TC5);
//	 }

//}



/*******************************************************
* �������ã���λ�����ݽ��մ����ж�
*
********************************************************/

void UART4_IRQHandler(void)
{
   if(USART_GetITStatus(UART4,USART_IT_IDLE) != RESET)
	 {
	    (void) UART4->SR;
	    (void) UART4->DR;
		  DMA_Cmd(DMA2_Channel3,DISABLE);
//		  short n;
//     	for(n=0;n<OFFET_RECE_SIZE;n++) 
//      {
//			  if(Offet_Rece[n] == 'A')
//				{
				  //PC_Receive(); 
		    //USART_ReceiveData(UART4);
				APP_Receive(Offet_Rece); //��λ�����ݴ������� 
//				}	
				
//			}		
			
		  DMA_SetCurrDataCounter(DMA2_Channel3,OFFET_RECE_SIZE);
		  DMA_Cmd(DMA2_Channel3,ENABLE);
			USART_ReceiveData(UART4);
		  USART_ClearITPendingBit(UART4,USART_IT_IDLE);
	    
	 }
	 


}
short i=0;
short SP_Rece_Flag = 0;
uint8_t Debug_Mode_Update_Flag = 0;
void APP_Receive(uint8_t data[])
{
	 switch(data[0])
	 {
		 //����֡ͷΪ'A'������,���õ����˶���ģʽ�����ٻ��Ǳ���
	   case 'A':
			     Last_Chassis_Debug_Mode = Chassis_Debug_Mode;
			     if(data[1] == 'S')
		    	 Chassis_Debug_Mode = 0;   
					 else if(data[1] == 'I')
					 Chassis_Debug_Mode = 1;
					 else if(data[1] == 'H')
					 Chassis_Debug_Mode = 2;
					 data[0] = 0;
					 if(Chassis_Debug_Mode != Last_Chassis_Debug_Mode)
					  Debug_Mode_Update_Flag = 1;
					 else 
						Debug_Mode_Update_Flag = 0;
		       break;
		 //����֡ͷΪ'B'������,���õ����˶���ģʽ�����ƻ�������
		 case 'B':
			     if(data[1] == 'L')
					 {
					   Turn_Left_Flag = 1;
						 Turn_Right_Flag = 0;
					 }
					 else 
					 {
					    Turn_Right_Flag = 1;
						  Turn_Left_Flag = 0;
					 }
					 data[0] = 0;
		       break;
		 //����֡ͷΪ'C'�����ݣ����õ��������˶����ٶ�ֵ
		 case 'C':
			     data[1] = data[1] - 48;
		       data[2] = data[2] -48;
		       App_Speed = (int16_t)(data[1]*1000+data[2]*100);
		       data[0] = 0;
		       //data[1] = 0;
		       //data[2] = 0;
		       break;
		 case 'D':
			     if(Offet_Rece[0] == 'D')
						{
//							for(int i=2;i<4;i++)
//							{
//								Offet_Send[i] = 1;
//							}
							
							Usart_SendArray(UART4,Offet_Send,OFFET_SEND_SIZE);
							Offet_Rece[0] = 0;
						}
		       break;
		 case 'E':
			     Sentry_State.Chassis_Mode =  Chassis_DEBUG;
		       //is_Under_Attack = 1;
		       //Led_Enable = 1; //�������ģʽ֮��ʼ���
		       
		       data[0] = 0;
		       break;
		 case 'F':
			     Sentry_State.Chassis_Mode = Chassis_SLEEP;
		        
			     data[0] = 0;
		       break;
		 case  'G':
			     R = 127;
		       G = 0;
		       B = 0;
		       DMA_end_flag = 0;
		       break;
		 case  'H':
			      R = 0;
		       G = 0;
		       B = 127;
		       DMA_end_flag = 0;
		       break;
		 default:
			    
		       break;
	 
	 }
 
	
	 SP_Rece_Flag = 1;
	 
   

}
//void UART4_IRQHandler(void)
//{
//	if (USART_GetITStatus(UART4, USART_IT_IDLE) != RESET)
//	{

//		(void)UART4->SR;   //Clear the IDLE int
//		(void)UART4->DR;	
//		
//		short n;
//		static int DATA_LENGTH0=0;
//		DMA_Cmd(DMA2_Channel3, DISABLE);
//		DATA_LENGTH0=13-DMA_GetCurrDataCounter(DMA2_Channel3);  //current data length in buffer
//		                                                                                                       
//		if(DATA_LENGTH0==GYRO_BUF_SIZE)
//		{
//			for(n=0;n<GYRO_BUF_SIZE;n++)
//			{
//				if(GYRO_Buffer[n] == 0x55)
//				{
//					Mpu6050ReceiveFunc(GYRO_Buffer,n);//Decoding
//				}
//			} 
////			DMA_Cmd(DMA2_Channel3,ENABLE);             //�о�������ж����غϵĵط�
////			DMA_SetCurrDataCounter(DMA2_Channel3,13);	
//	  }
////		else
////		{
//			DMA_Cmd(DMA2_Channel3,ENABLE);
//		  DMA_SetCurrDataCounter(DMA2_Channel3,13);	
////		}
//		//DMA_Cmd(DMA2_Channel3,ENABLE);
//	}
//}


/**************************************************************
* ��������:MPU6050Receive
* ��������:����mpu6050����������
* �� �� ֵ:��
**************************************************************/

//extern volatile uint32_t CPU_Runtime;
//extern Com_offet_t com_offet;
//void Mpu6050ReceiveFunc(unsigned char gyroBuffer[],short BufferNum)  //BufferNumΪ֡ͷ��λ��
//{
//	Mpu6050Receive.LastYawAngle = Mpu6050Receive.ReceiveYawAngle;
//	switch(gyroBuffer[(BufferNum+1)])
//	{	
//		case 0x53://Angle Buff
//		Mpu6050Receive.ReceiveYawAngle = ((short)(gyroBuffer[(BufferNum+7)%GYRO_BUF_SIZE]<<8 | gyroBuffer[(BufferNum+6)%GYRO_BUF_SIZE]))/32767.0*180;//�õ�YAWangle
//		Mpu6050Receive.Temp = ((short)(gyroBuffer[(BufferNum+9)%GYRO_BUF_SIZE]<<8 | gyroBuffer[(BufferNum+8)%GYRO_BUF_SIZE]))/340.0+36.25;
//		break;
//	}
//	/*Zero_Check*/
//	if(Mpu6050Receive.LastYawAngle-Mpu6050Receive.ReceiveYawAngle>100)   //����Ƿ�ת��һȦ��,
//	 Mpu6050Receive.ZeroCircle++;
//	if(Mpu6050Receive.LastYawAngle-Mpu6050Receive.ReceiveYawAngle<-100)
//	 Mpu6050Receive.ZeroCircle--;
//  Mpu6050Receive.YawAngle = Mpu6050Receive.ReceiveYawAngle + Mpu6050Receive.ZeroCircle*180.0;
//	
//	//�жϴ����жϲ���
//	com_offet.Uart_offet.Uart_gyro_Cur_Num++;
//	com_offet.Uart_offet.Uart_gyro_Last_Num = com_offet.Uart_offet.Uart_gyro_Cur_Num;
//	
////	com_offet.Uart_offet.Uart_gyro_Last_time = com_offet.Uart_offet.Uart_gyro_Cur_time;
////	com_offet.Uart_offet.Uart_gyro_Cur_time = CPU_RunTime;
////	
////	if((com_offet.Uart_offet.Uart_gyro_Cur_time-com_offet.Uart_offet.Uart_gyro_Last_time)>100)
////	   com_offet.Uart_offet.Uart_gyro_offet = 1;
////	else 
////		 com_offet.Uart_offet.Uart_gyro_offet = 0;
////	
//}

/**
  * @brief  Return ReceiveGyroYawAngle
  * @param 
  * @retval 
  */
//float GyroYawAngle(void)
//{
//	return Mpu6050Receive.YawAngle;
//}

#include "main.h"
#include "string.h"

CanRxMsg Can1_rx_message_0, Can1_rx_message_1, Can2_rx_message_0, Can2_rx_message_1;
extern uint8_t is_Under_Attack;
uint8_t count = 0;
/**********************CAN1**********************************/
/**
  * @brief  ����CAN1
  * @param  None
  * @retval None
  */
void CAN1_Configuration(void)
{
    GPIO_InitTypeDef gpioInit;
    CAN_InitTypeDef canInit;
    CAN_FilterInitTypeDef canFilterInit;
    NVIC_InitTypeDef nvicInit;

    /* ��GPIOʱ�ӡ�AFIOʱ�ӣ�CANʱ�� */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);

    //	GPIO_PinRemapConfig(GPIO_Remap1_CAN1,ENABLE);  // CAN1 remap

    /* CAN1 RX PA11 */
    gpioInit.GPIO_Pin = GPIO_Pin_8;
    gpioInit.GPIO_Mode = GPIO_Mode_IPU;
    gpioInit.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &gpioInit);
    /* CAN1 TX PA12 */
    gpioInit.GPIO_Pin = GPIO_Pin_9;
    gpioInit.GPIO_Mode = GPIO_Mode_AF_PP;
    gpioInit.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &gpioInit);

    GPIO_PinRemapConfig(GPIO_Remap1_CAN1,ENABLE);  // CAN1 remap
		 
    /* CAN1 Enabling interrupt */
    nvicInit.NVIC_IRQChannel = CAN1_RX0_IRQn;
    nvicInit.NVIC_IRQChannelPreemptionPriority = 1;
    nvicInit.NVIC_IRQChannelSubPriority = 0;
    nvicInit.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvicInit);

    nvicInit.NVIC_IRQChannel = CAN1_RX1_IRQn;
    nvicInit.NVIC_IRQChannelPreemptionPriority = 1;
    nvicInit.NVIC_IRQChannelSubPriority = 0;
    nvicInit.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvicInit);

    nvicInit.NVIC_IRQChannel = CAN1_TX_IRQn;
    nvicInit.NVIC_IRQChannelPreemptionPriority = 1;
    nvicInit.NVIC_IRQChannelSubPriority = 0;
    nvicInit.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvicInit);

    /* CAN  BaudRate = RCC_APB1PeriphClock/(CAN_SJW+CAN_BS1+CAN_BS2)/CAN_Prescaler */
    CAN_DeInit(CAN1);
    CAN_StructInit(&canInit);

    canInit.CAN_TTCM = DISABLE;
    canInit.CAN_ABOM = ENABLE;
    canInit.CAN_AWUM = ENABLE;
    canInit.CAN_NART = ENABLE;
    canInit.CAN_RFLM = DISABLE;
    canInit.CAN_TXFP = ENABLE;
    canInit.CAN_Mode = CAN_Mode_Normal;
    //canInit.CAN_Mode=CAN_Mode_LoopBack;
    canInit.CAN_SJW = CAN_SJW_1tq;
    canInit.CAN_BS1 = CAN_BS1_5tq;
    canInit.CAN_BS2 = CAN_BS2_3tq;
    canInit.CAN_Prescaler = 4;

    CAN_Init(CAN1, &canInit); // CAN1
    canFilterInit.CAN_FilterNumber = 0;
    canFilterInit.CAN_FilterMode = CAN_FilterMode_IdList;  // ��ʶ���б�ģʽ
    canFilterInit.CAN_FilterScale = CAN_FilterScale_16bit; // 32λ������
    canFilterInit.CAN_FilterIdHigh = 0x201 << 5;           // ��������ʶ��
    canFilterInit.CAN_FilterIdLow = 0x202 << 5;
    canFilterInit.CAN_FilterMaskIdHigh = 0x203 << 5; // ���������α�ʶ��
    canFilterInit.CAN_FilterMaskIdLow = 0x204 << 5;
    canFilterInit.CAN_FilterFIFOAssignment = CAN_FIFO0; // FIFO0ָ�������
    canFilterInit.CAN_FilterActivation = ENABLE;
    CAN_FilterInit(&canFilterInit);


    //���FIFO1Ŀǰ��û�õ� //׼�������ͼ���ͨ�������������F105�Ͻ��д������ļ��Ļ�
    canFilterInit.CAN_FilterNumber = 1;
    canFilterInit.CAN_FilterMode = CAN_FilterMode_IdList;  // ��ʶ������λģʽ
    canFilterInit.CAN_FilterScale = CAN_FilterScale_16bit; // 32λ������
    canFilterInit.CAN_FilterIdHigh = 0x501 << 5;           // ��������ʶ��
    canFilterInit.CAN_FilterIdLow = 0x502 << 5;
    canFilterInit.CAN_FilterMaskIdHigh = 0x503 << 5;       // ���������α�ʶ��
    canFilterInit.CAN_FilterMaskIdLow = 0x504 << 5;
    canFilterInit.CAN_FilterFIFOAssignment = CAN_FIFO1;    // FIFO1ָ�������
    canFilterInit.CAN_FilterActivation = ENABLE;
    CAN_FilterInit(&canFilterInit);

    CAN_ITConfig(CAN1, CAN_IT_FMP0, ENABLE);
    CAN_ITConfig(CAN1, CAN_IT_FMP1, ENABLE);
    CAN_ITConfig(CAN1, CAN_IT_TME, ENABLE);

//      GPIO_InitTypeDef GPIO_InitStructure;
//		CAN_InitTypeDef        CAN_InitStructure;
//		CAN_FilterInitTypeDef  CAN_FilterInitStructure;
//		NVIC_InitTypeDef NVIC_InitStructure;

//		/* ��GPIOʱ�ӡ�AFIOʱ�ӣ�CANʱ�� */
//		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
//		RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);


//		/* CAN1 RX PB8 */
//		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
//		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
//		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//		GPIO_Init(GPIOB, &GPIO_InitStructure);
//		/* CAN1 TX PB9 */
//		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
//		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
//		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//		GPIO_Init(GPIOB, &GPIO_InitStructure);

//		GPIO_PinRemapConfig(GPIO_Remap1_CAN1,ENABLE);  // CAN1 remap

////		/* CAN1 RX PB8 */
////		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
////		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
////		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
////		GPIO_Init(GPIOA, &GPIO_InitStructure);
////		/* CAN1 TX PB9 */
////		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
////		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
////		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
////		GPIO_Init(GPIOA, &GPIO_InitStructure);


//		/* CAN1 Enabling interrupt */									  
//		NVIC_InitStructure.NVIC_IRQChannel=CAN1_RX0_IRQn;
//		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
//		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
//		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//		NVIC_Init(&NVIC_InitStructure);									
//									
//		/* CAN  BaudRate = RCC_APB1PeriphClock/(CAN_SJW+CAN_BS1+CAN_BS2)/CAN_Prescaler */
//		CAN_DeInit(CAN1);
//		CAN_StructInit(&CAN_InitStructure);   

//		CAN_InitStructure.CAN_TTCM=DISABLE;
//		CAN_InitStructure.CAN_ABOM=ENABLE;
//		CAN_InitStructure.CAN_AWUM=ENABLE;
//		CAN_InitStructure.CAN_NART=ENABLE;
//		CAN_InitStructure.CAN_RFLM=DISABLE;
//		CAN_InitStructure.CAN_TXFP=ENABLE;
//		CAN_InitStructure.CAN_Mode=CAN_Mode_Normal;   
//		//CAN_InitStructure.CAN_Mode=CAN_Mode_LoopBack;
//		CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;
//		CAN_InitStructure.CAN_BS1=CAN_BS1_5tq;  
//		CAN_InitStructure.CAN_BS2=CAN_BS2_3tq;	
//		CAN_InitStructure.CAN_Prescaler=4;


//		CAN_Init(CAN1,&CAN_InitStructure);	// CAN1											

//		CAN_FilterInitStructure.CAN_FilterNumber=0;	 
//		CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdList;	 // ��ʶ������λģʽ
//		CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_16bit;   // 32λ������
//		CAN_FilterInitStructure.CAN_FilterIdHigh=0x201<<5;			// ��������ʶ��
//		CAN_FilterInitStructure.CAN_FilterIdLow=0x202<<5;				
//		CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0x203<<5;		// ���������α�ʶ��
//		CAN_FilterInitStructure.CAN_FilterMaskIdLow=0x204<<5;
//		CAN_FilterInitStructure.CAN_FilterFIFOAssignment=CAN_FIFO0;	 // FIFO0ָ�������
//		CAN_FilterInitStructure.CAN_FilterActivation=ENABLE;
//		CAN_FilterInit(&CAN_FilterInitStructure);
//		CAN_ITConfig(CAN1,CAN_IT_FMP0,ENABLE);  // CAN1
//		CAN_ITConfig(CAN1,CAN_IT_TME,ENABLE);  
}

/**
  * @brief  CAN1�����ж�0
  * @param  None
  * @retval None
  */
void CAN1_RX0_IRQHandler(void)
{
	 //CanRxMsg Can1_rx_message_0;
    if (CAN_GetITStatus(CAN1, CAN_IT_FMP0) != RESET)
    {
			 //count++;
			 CAN_ClearITPendingBit(CAN1, CAN_IT_FMP0);
        //CAN_Receive(CAN1, CAN_FIFO0, &Can1_rx_message_0);
       // CAN1_DataReceive_0();
//			  if (Can1_rx_message_0.StdId == MOTOR_CHASSIS_ID) //���̵����ID��
//	{
//        extern _3508_motor_t motor_chassis;
////		block_disconnect.Chassis_Last_Cnt = GetSysCnt();
//		motor_chassis.angle_abs  = Can1_rx_message_0.Data[0] << 8 | Can1_rx_message_0.Data[1];
//		motor_chassis.real_speed = Can1_rx_message_0.Data[2] << 8 | Can1_rx_message_0.Data[3];
//    motor_chassis.real_flow  = Can1_rx_message_0.Data[4] << 8 | Can1_rx_message_0.Data[5];
//	}    
//	    if (Can1_rx_message_0.StdId == F103_ID)
//	{
//	  is_Under_Attack = (uint16_t)Can1_rx_message_0.Data[0];
//	}
       // CAN_ClearITPendingBit(CAN1, CAN_IT_FMP0);
    }
}

/**
  * @brief  CAN1�����ж�1
  * @param  None
  * @retval None
  */
//void CAN1_RX1_IRQHandler(void)
//{
//    if (CAN_GetITStatus(CAN1, CAN_IT_FMP1) != RESET)
//    {
//        CAN_Receive(CAN1, CAN_FIFO1, &Can1_rx_message_1);
//        CAN1_DataReceive_1();
//			  //CAN1_DataReceive_1();
//        CAN_ClearITPendingBit(CAN1, CAN_IT_FMP1);
//    }
//}
/**
  * @brief  CAN1�����ж�
  * @param  None
  * @retval None
  */
void CAN1_TX_IRQHandler(void)
{
    if (CAN_GetITStatus(CAN1, CAN_IT_TME) != RESET)
    {
        CAN_ClearITPendingBit(CAN1, CAN_IT_TME);
    }
}

/******************************CAN2*****************************************/
/**
  * @brief  ����CAN2
  * @param  None
  * @retval None
  */
void CAN2_Configuration(void)
{
    GPIO_InitTypeDef gpioInit;
    CAN_InitTypeDef canInit;
    CAN_FilterInitTypeDef canFilterInit;
    NVIC_InitTypeDef nvicInit;

    /* ��GPIOʱ�ӡ�AFIOʱ�ӣ�CANʱ�� */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN2, ENABLE);

    /* CAN2 RX PB12 */
    gpioInit.GPIO_Pin = GPIO_Pin_12;
    gpioInit.GPIO_Mode = GPIO_Mode_IPU;
    gpioInit.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &gpioInit);
    /* CAN2 TX PB13 */
    gpioInit.GPIO_Pin = GPIO_Pin_13;
    gpioInit.GPIO_Mode = GPIO_Mode_AF_PP;
    gpioInit.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &gpioInit);

    /* CAN2 Enabling interrupt */
    nvicInit.NVIC_IRQChannel = CAN2_RX0_IRQn; // FIFO_0
    nvicInit.NVIC_IRQChannelPreemptionPriority = 1;
    nvicInit.NVIC_IRQChannelSubPriority = 0;
    nvicInit.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvicInit);

    /* CAN2 Enabling interrupt */
    nvicInit.NVIC_IRQChannel = CAN2_RX1_IRQn; // FIFO_1
    nvicInit.NVIC_IRQChannelPreemptionPriority = 1;
    nvicInit.NVIC_IRQChannelSubPriority = 0;
    nvicInit.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvicInit);

    /* CAN2 Enabling interrupt */
    nvicInit.NVIC_IRQChannel = CAN2_TX_IRQn; // TX
    nvicInit.NVIC_IRQChannelPreemptionPriority = 1;
    nvicInit.NVIC_IRQChannelSubPriority = 0;
    nvicInit.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvicInit);

    /* CAN  BaudRate = RCC_APB1PeriphClock/(CAN_SJW+CAN_BS1+CAN_BS2)/CAN_Prescaler */
    CAN_DeInit(CAN2);
    CAN_StructInit(&canInit);

    canInit.CAN_TTCM = DISABLE;
    canInit.CAN_ABOM = ENABLE;
    canInit.CAN_AWUM = ENABLE;
    canInit.CAN_NART = ENABLE;
    canInit.CAN_RFLM = DISABLE;
    canInit.CAN_TXFP = ENABLE;
    canInit.CAN_Mode = CAN_Mode_Normal;
    //canInit.CAN_Mode=CAN_Mode_LoopBack;
    canInit.CAN_SJW = CAN_SJW_1tq;
    canInit.CAN_BS1 = CAN_BS1_5tq;
    canInit.CAN_BS2 = CAN_BS2_3tq;
    canInit.CAN_Prescaler = 4;

    CAN_Init(CAN2, &canInit); // CAN2

    canFilterInit.CAN_FilterNumber = 15;                     //
    canFilterInit.CAN_FilterMode = CAN_FilterMode_IdList;    // ��ʶ������λģʽ
    canFilterInit.CAN_FilterScale = CAN_FilterScale_16bit;   // 32λ������
    canFilterInit.CAN_FilterIdHigh = Remote_Control_ID << 5; // ��������ʶ��
    canFilterInit.CAN_FilterIdLow =  SHOOTING_HEAT_ID << 5;
    canFilterInit.CAN_FilterMaskIdHigh =  0 <<5;		// ���������α�ʶ��
    canFilterInit.CAN_FilterMaskIdLow =   0<<5;
    canFilterInit.CAN_FilterFIFOAssignment = CAN_FIFO0;      // FIFO0ָ�������
    canFilterInit.CAN_FilterActivation = ENABLE;
    CAN_FilterInit(&canFilterInit);


     canFilterInit.CAN_FilterNumber = 16;                   //
     canFilterInit.CAN_FilterMode = CAN_FilterMode_IdList;  // ��ʶ������λģʽ
     canFilterInit.CAN_FilterScale = CAN_FilterScale_16bit; // 32λ������
     canFilterInit.CAN_FilterIdHigh = 0x201 << 5;       // ��������ʶ��
     canFilterInit.CAN_FilterIdLow = 0x401 << 5;
     canFilterInit.CAN_FilterMaskIdHigh = 0x203 << 5; // ���������α�ʶ��
     canFilterInit.CAN_FilterMaskIdLow = 0x204 << 5;
     canFilterInit.CAN_FilterFIFOAssignment = CAN_FIFO1; // FIFO1ָ�������
     canFilterInit.CAN_FilterActivation = ENABLE;
     CAN_FilterInit(&canFilterInit);

    CAN_ITConfig(CAN2, CAN_IT_FMP0, ENABLE);
    CAN_ITConfig(CAN2, CAN_IT_FMP1, ENABLE);
    CAN_ITConfig(CAN2, CAN_IT_TME, ENABLE);
}

/**
  * @brief  CAN2�����ж�
  * @param  None
  * @retval None
  */
void CAN2_RX0_IRQHandler(void)
{
    if (CAN_GetITStatus(CAN2, CAN_IT_FMP0) != RESET)
    {
        CAN_Receive(CAN2, CAN_FIFO0, &Can2_rx_message_0);
        CAN2_DataReceive_0();
        CAN_ClearITPendingBit(CAN2, CAN_IT_FMP0);
    }
}

/**
  * @brief  CAN2�����ж�
  * @param  None
  * @retval None
  */
void CAN2_RX1_IRQHandler(void)
{
    if (CAN_GetITStatus(CAN2, CAN_IT_FMP1) != RESET)
    {
        CAN_Receive(CAN2, CAN_FIFO1, &Can2_rx_message_1);
        CAN2_DataReceive_1();
        CAN_ClearITPendingBit(CAN2, CAN_IT_FMP1);
    }
}

/**
  * @brief  CAN2�����ж�
  * @param  None
  * @retval None
  */
void CAN2_TX_IRQHandler(void)
{
    if (CAN_GetITStatus(CAN2, CAN_IT_TME) != RESET)
    {
        CAN_ClearITPendingBit(CAN2, CAN_IT_TME);
    }
}

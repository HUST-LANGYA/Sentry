//#ifndef __BSP_TIM3_ENCODER_H
//#define __BSP_TIM3_ENCODER_H

////#define START_POS			-10000
////#define FIRST_CORNER  0		//2315 - 30cm
////#define SECOND_CORNER 0
////#define END_POS				10000
//#define SK6812_NUMBER 60
//#define ESC_CMD_BUFFER_LEN (SK6812_NUMBER*24)
//#define SEND_LEN  ESC_CMD_BUFFER_LEN
//#define ESC_BIT_0 5  //ռ�ձ�Ϊ30%
//#define ESC_BIT_1 11   //ռ�ձ�Ϊ50%

//// void TIM3_Configuration_Limit_Switch(void);
//void TIM3_Config_Encoder(void);
//void Set_SK6812Value(uint8_t R,uint8_t G,uint8_t B,uint8_t led);
//void Sk6812_Show(void);
/////*inline*/ uint16_t Read_Encoder(void);

////int32_t GetJourney(void);
////void Encoder_detect(void);

//#endif //__BSP_TIM3_ENCODER_H

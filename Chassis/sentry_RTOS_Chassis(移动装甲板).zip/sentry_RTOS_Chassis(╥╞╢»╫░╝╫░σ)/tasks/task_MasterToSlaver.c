
#include "main.h"

extern uint8_t Offet_Send[OFFET_SEND_SIZE]; //APP������
extern uint8_t Offet_Rece[OFFET_RECE_SIZE]; //APP����������

void task_MasterToSlaver(void* parameter)
{
    
	while(1)
	{
//		if(Offet_Rece[0] == 'D')
//		{
//			for(int i=3;i<4;i++)
//			{
//			  Offet_Send[i] = 1;
//			}
//			
//		  Usart_SendArray(UART4,Offet_Send,OFFET_SEND_SIZE);
//			Offet_Rece[0] = 0;
//		}
//	  //Bodan_CAN1Send(10);
		
	  vTaskDelay(5);
	}
  

}



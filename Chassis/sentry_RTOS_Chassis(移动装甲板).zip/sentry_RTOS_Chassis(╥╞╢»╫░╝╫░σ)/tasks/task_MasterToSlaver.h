#ifndef _TASK_MASTERTOSLAVER_H
#define _TASK_MASTERTOSLAVER_H



void task_MasterToSlaver(void* parameter);




#endif



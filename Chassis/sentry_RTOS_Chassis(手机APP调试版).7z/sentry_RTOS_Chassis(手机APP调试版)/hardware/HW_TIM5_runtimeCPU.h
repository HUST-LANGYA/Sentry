#ifndef __HW_TIM5_runtimeCPU_H
#define __HW_TIM5_runtimeCPU_H

void TIM5_Configuration(void);   //监测CPU占用率

#endif //  __HW_TIM5_runtimeCPU_H


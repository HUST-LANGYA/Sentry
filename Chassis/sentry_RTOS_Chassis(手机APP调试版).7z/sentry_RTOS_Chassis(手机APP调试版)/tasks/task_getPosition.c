#include "main.h"
#include "task_getPosition.h"


/**
 *  @brief  获取各传感器的位置信息，做融合运算，然后给到巡逻任务里去
 *  @param  无
 *  @retval 无
 */
void task_getPositon(void)
{
    while (1)
    {

        
        vTaskDelay(1);
    }
}
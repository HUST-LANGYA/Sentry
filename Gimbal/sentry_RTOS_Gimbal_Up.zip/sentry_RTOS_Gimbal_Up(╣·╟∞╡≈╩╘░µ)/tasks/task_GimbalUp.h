#ifndef __TASK_GIMBALUP_H
#define __TASK_GIMBALUP_H

#define gyroLimitYaw   30000
#define gyroLimitPitch 30000 

void task_GimbalUp(void* parameter);

#endif //__TASK_GIMBALUP_H

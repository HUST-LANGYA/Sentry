#ifndef __BSP_TIM8_PWM_H
#define __BSP_TIM8_PWM_H

void TIM8_Configuration(void);

#endif //__BSP_TIM8_PWM_H

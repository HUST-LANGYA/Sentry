#ifndef __HW_USART3_RC_H
#define __HW_USART3_RC_H

#define RX_USART3_BUFFER 18//30

void USART3_Configuration(void);

#endif //__HW_USART3_RC_H

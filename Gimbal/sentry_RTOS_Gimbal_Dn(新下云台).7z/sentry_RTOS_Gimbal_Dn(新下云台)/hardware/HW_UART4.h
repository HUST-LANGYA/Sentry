#ifndef __BSP_UART4_H
#define __BSP_UART4_H

#define RX_UART4_BUFFER 24
#define GYRO_BUF_SIZE 18

void UART4_Configuration(void);

#endif //__BSP_UART4_H

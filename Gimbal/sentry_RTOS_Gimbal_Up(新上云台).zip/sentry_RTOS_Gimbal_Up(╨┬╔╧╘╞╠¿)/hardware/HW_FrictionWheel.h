#ifndef __DEV_FRICTIONWHEEL_H
#define __DEV_FRICTIONWHEEL_H

void FrictionWheel_SetSpeed(int16_t tmpAccelerator0, int16_t tmpAccelerator1);
void FrictionWheel_Init(void);

#endif //__DEV_FRICTIONWHEEL_H
